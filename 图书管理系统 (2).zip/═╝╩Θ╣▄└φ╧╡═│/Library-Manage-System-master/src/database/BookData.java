 package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;

import javax.swing.table.DefaultTableModel;

public class BookData {
	/*��ʾȫ��ͼ��*/
	public void selectAll(DefaultTableModel model) throws Exception {
		String sql = "select * from book";
		Connection con;
		ResultSet rs;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps = con.prepareStatement(sql);
		rs = ps.executeQuery();
		while (rs.next()) {
			String Book = rs.getString(1);
			String Author = rs.getString(2);
			int BookNo = rs.getInt(3);
			int StockQuantiy = rs.getInt(4);
			String Location = rs.getString(5);
			String BookType = rs.getString(6);
			boolean BookStatus = rs.getBoolean(7);
			if (BookStatus == false)
				model.addRow(new Vector<>(Arrays.asList(Book, Author, BookNo, StockQuantiy, Location, BookType, "�ɽ�")));
			else
				model.addRow(new Vector<>(Arrays.asList(Book, Author, BookNo, StockQuantiy, Location, BookType, "���ɽ�")));
		}
		con.close();
	}

	/*������������ͼ��*/
	public void bookSelect(DefaultTableModel model, String book) throws Exception {
		String sql = "select * from book where BookTitle like ?";
		Connection con;
		ResultSet rs;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps = con.prepareStatement(sql);
		book = "%" + book + "%";
		ps.setString(1, book);
		rs = ps.executeQuery();
		while (rs.next()) {
			String Book = rs.getString(1);
			String Author = rs.getString(2);
			int BookNo = rs.getInt(3);
			int StockQuantiy = rs.getInt(4);
			String Location = rs.getString(5);
			String BookType = rs.getString(6);
			boolean BookStatus = rs.getBoolean(7);
			if (BookStatus == false)
				model.addRow(new Vector<>(Arrays.asList(Book, Author, BookNo, StockQuantiy, Location, BookType, "�ɽ�")));
			else
				model.addRow(new Vector<>(Arrays.asList(Book, Author, BookNo, StockQuantiy, Location, BookType, "���ɽ�")));
		}
		con.close();
	}

	/*������������ͼ��*/
	public void authorSelect(DefaultTableModel model, String author) throws Exception {
		String sql = "select * from book where Author like ?";
		Connection con;
		ResultSet rs;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps = con.prepareStatement(sql);
		author = "%" + author + "%";
		ps.setString(1, author);
		rs = ps.executeQuery();
		while (rs.next()) {
			String Book = rs.getString(1);
			String Author = rs.getString(2);
			int BookNo = rs.getInt(3);
			int StockQuantiy = rs.getInt(4);
			String Location = rs.getString(5);
			String BookType = rs.getString(6);
			boolean BookStatus = rs.getBoolean(7);
			if (BookStatus == false)
				model.addRow(new Vector<>(Arrays.asList(Book, Author, BookNo, StockQuantiy, Location, BookType, "�ɽ�")));
			else
				model.addRow(new Vector<>(Arrays.asList(Book, Author, BookNo, StockQuantiy, Location, BookType, "���ɽ�")));
		}
		con.close();
	}

	/*���ձ������ͼ��*/
	public void idSelect(DefaultTableModel model, int id) throws Exception {
		String sql = "select * from book where BookID = ?";
		Connection con;
		ResultSet rs;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps = con.prepareStatement(sql);
		ps.setInt(1, id);
		rs = ps.executeQuery();
		while (rs.next()) {
			String Book = rs.getString(1);
			String Author = rs.getString(2);
			int BookNo = rs.getInt(3);
			int StockQuantiy = rs.getInt(4);
			String Location = rs.getString(5);
			String BookType = rs.getString(6);
			boolean BookStatus = rs.getBoolean(7);
			if (BookStatus == false)
				model.addRow(new Vector<>(Arrays.asList(Book, Author, BookNo, StockQuantiy, Location, BookType, "�ɽ�")));
			else
				model.addRow(new Vector<>(Arrays.asList(Book, Author, BookNo, StockQuantiy, Location, BookType, "���ɽ�")));
		}
		con.close();
	}
	/*���ձ������ͼ��*/
	public void typeSelect(DefaultTableModel model, String type) throws Exception {
		String sql = "select * from book where BookType like ?";
		Connection con;
		ResultSet rs;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps = con.prepareStatement(sql);
		type = "%" + type + "%";
		ps.setString(1, type);
		rs = ps.executeQuery();
		while (rs.next()) {
			String Book = rs.getString(1);
			String Author = rs.getString(2);
			int BookNo = rs.getInt(3);
			int StockQuantiy = rs.getInt(4);
			String Location = rs.getString(5);
			String BookType = rs.getString(6);
			boolean BookStatus = rs.getBoolean(7);
			if (BookStatus == false)
				model.addRow(new Vector<>(Arrays.asList(Book, Author, BookNo, StockQuantiy, Location, BookType, "�ɽ�")));
			else
				model.addRow(new Vector<>(Arrays.asList(Book, Author, BookNo, StockQuantiy, Location, BookType, "���ɽ�")));
		}
		con.close();
	}
	/*��ѯ��������*/
	public int selectnum(String name) throws SQLException {
		String sql = "select count(*) from record where Borrow_name=? and status=0";
		Connection con;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		ResultSet rs;
		con = cd.connect();
		ps = con.prepareStatement(sql);
		ps.setString(1, name);
		rs = ps.executeQuery();
		int num = 0;
		if (rs.next()) num = rs.getInt(1);
		return num;
	}

	/*�����ڹ���ϢΪ���*/
	public void updatelend(DefaultTableModel model, String book) throws Exception {
		String sql = "update book set StockQuantity =StockQuantity-1 where BookTitle = ?";
		Connection con;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps = con.prepareStatement(sql);
		ps.setString(1, book);
		int ok = ps.executeUpdate();
		con.close();
		model.setRowCount(0);
		selectAll(model);
		con.close();
	}

	/*�����ڹ���ϢΪ�˻�*/
	public void updatereturn(DefaultTableModel model, int bookid) throws Exception {
		String sql1 = "update Record set status = 1 where Borrow_book_id = ?";
		String sql2 = "update book set StockQuantity =StockQuantity+1 where BookID=?";
		Connection con;
		PreparedStatement ps1;
		PreparedStatement ps2;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps1 = con.prepareStatement(sql1);
		ps2 = con.prepareStatement(sql2);
		ps1.setInt(1, bookid);
		ps2.setInt(1, bookid);
		int ok1 = ps1.executeUpdate();
		int ok2 = ps2.executeUpdate();
		model.setRowCount(0);
		selectAll(model);
		con.close();
	}

	/*�ѽ�����ʷ�������ݿ�*///lzc�޸�
	public void addHistory(int id, String borrower) throws Exception {
		String sql = "insert into Record(Borrow_name,Borrow_book_id) values (?,?)";
		Connection con;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps = con.prepareStatement(sql);
		ps.setString(1, borrower);
		ps.setInt(2, id);
		int ok = ps.executeUpdate();
		con.close();
	}

	/*��ʾ������ʷ*///lzc�޸�
	public void showHistory(DefaultTableModel model, String borrower) throws Exception {
		model.setRowCount(0);
		String sql = "select * from Record where Borrow_name= ?";
		Connection con;
		ResultSet rs;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps = con.prepareStatement(sql);
		ps.setString(1, borrower);
		rs = ps.executeQuery();
		while (rs.next()) {
			int BookNo = rs.getInt(3);
			Date Time = rs.getDate(1);
			Boolean status = rs.getBoolean(4);
			//��Timeת����LocalDate���������ټ���һ������ת������
			Calendar calendar = Calendar.getInstance();
			// ��ȡ��ǰ����
			// ���� Calendar �����ʱ��Ϊ��ǰ����
			calendar.setTime(Time);
			// �� Calendar ������·����� 1
			calendar.add(Calendar.MONTH, 1);
			// ��ȡ����һ���º������
			Date time = calendar.getTime();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String return_time = sdf.format(time);
			if (!status)
				model.addRow(new Vector<>(Arrays.asList(BookNo, borrower, Time, return_time, "δ��")));
			else model.addRow(new Vector<>(Arrays.asList(BookNo, borrower, Time, return_time, "�ѻ�")));
		}
		con.close();
	}

	public boolean needreturn(int bookid, String borrower) throws Exception {
		String sql = "select * from Record where Borrow_book_id= ? and Borrow_name=? and status=0";
		Connection con;
		ResultSet rs;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps = con.prepareStatement(sql);
		ps.setInt(1, bookid);
		ps.setString(2, borrower);
		rs = ps.executeQuery();
		return rs.isBeforeFirst();
	}

	/*��������*/
	public boolean returnalert(String name) throws Exception {
		String sql = "SELECT * FROM record WHERE DATEDIFF(DAY, Borrow_time, GETDATE()) > 25 and Borrow_name=? and status=0";
		Connection con;
		ResultSet rs;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps = con.prepareStatement(sql);
		ps.setString(1, name);
		rs = ps.executeQuery();
		return rs.isBeforeFirst();
	}

	/*�鿴�û��Ƿ�Ƿ��*/
	public boolean checkdebt(String borrower) throws SQLException {
		String sql = "select * from users where username= ? and debt_status=1";
		Connection con;
		ResultSet rs;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps = con.prepareStatement(sql);
		ps.setString(1, borrower);
		rs = ps.executeQuery();
		return rs.isBeforeFirst();
	}

	/*�鿴�û��Ƿ����Ȿ��*/
	public boolean alreadyBorrow(int bookid, String borrower) throws Exception {
		String sql = "select * from Record where Borrow_book_id= ? and Borrow_name=? and status=0";
		Connection con;
		ResultSet rs;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps = con.prepareStatement(sql);
		ps.setInt(1, bookid);
		ps.setString(2, borrower);
		rs = ps.executeQuery();
		return rs.isBeforeFirst();
	}

	/*�����û����ݾ����ܽ輸����*/
	public int characterDecide(String borrower) throws Exception {
		String sql = "select * from users where username=?";
		Connection con;
		ResultSet rs;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps = con.prepareStatement(sql);
		ps.setString(1, borrower);
		rs = ps.executeQuery();
		String character=null;
		while(rs.next()) {
			character = rs.getString(4);
		}
		if (character.equals("������")) {
			return 3;
		} else if (character.equals("�о���")) {
			return 5;
		} else if (character.equals("��ְԱ��")) {
			return 7;
		} else {
			return 0;
		}
	}
}
	


