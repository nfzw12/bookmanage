package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ManageBook {
	
	/*�����ݿ�����ͼ��*/
	public void addBook(String BookTitle,String Author,int BookID,int StockQuantity,String Location,String BookType,boolean BookStatus) throws Exception{
		String sql = "insert into book values (?,?,?,?,?,?,?)";
		Connection con;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps = con.prepareStatement(sql);
		ps.setString(1, BookTitle);
		ps.setString(2, Author);
		ps.setInt(3, BookID);
		ps.setInt(4, StockQuantity);
		ps.setString(5,Location);
		ps.setString(6,BookType);
		ps.setBoolean(7,BookStatus);
		int ok = ps.executeUpdate();
		con.close();
	}
	/*�޸�ͼ����Ϣ*/
	public void changeBook(int id,int stockquantity,String location,Boolean status) throws Exception{
		String sql = "update book set StockQuantity = ?,Location = ?,BookStatus=? where BookID = ?";
		Connection con;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps = con.prepareStatement(sql);
		ps.setInt(1, stockquantity);
		ps.setString(2, location);
		ps.setBoolean(3,status);
		ps.setInt(4,id);
		int ok = ps.executeUpdate();
		con.close();
	}
/*	public void changeAuthor(int id,String author) throws Exception{
		String sql = "update book set Author = ? where BookID = ?";
		Connection con;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps = con.prepareStatement(sql);
		ps.setString(1, author);
		ps.setInt(2, id);
		int ok = ps.executeUpdate();
		con.close();
	}*/
	/*ɾ��ͼ����Ϣ*/
	public void delete(int id) throws Exception{
		String sql = "delete from book where BookID = ?";
		Connection con;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps = con.prepareStatement(sql);
		ps.setInt(1, id);
		int ok = ps.executeUpdate();
		con.close();
	}
}
