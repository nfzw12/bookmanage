package database;

import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Arrays;
import java.util.Vector;

public class AnalyseData {
    public void selectAll(DefaultTableModel model) throws Exception {
        String sql1 = "SELECT COUNT(*) FROM users";
        String sql2= " select count(*) from record";
        String sql3="SELECT COUNT(*) FROM users where debt_status = 1";
        int count1 = 0,count2=0,count3=0;
        Connection con;
        ResultSet rs;
        PreparedStatement ps;
        ConnectData cd = new ConnectData();
        con = cd.connect();
        ps = con.prepareStatement(sql1);
        rs = ps.executeQuery();
        while (rs.next()) {
            count1 = rs.getInt(1);
            ps = con.prepareStatement(sql2);
            ResultSet rs2 = ps.executeQuery();
            if (rs2.next()) {
                count2 = rs2.getInt(1);
            }
            ps = con.prepareStatement(sql3);
            ResultSet rs3 = ps.executeQuery();
            if (rs3.next()) {
                count3 = rs3.getInt(1);
            }
        }
        model.addRow(new Vector<>(Arrays.asList(count1,count2,count3)));
        con.close();
    }
    public void selectAllUsers(DefaultTableModel model) throws Exception {
        String sql1 = "SELECT user_id,username,role,debt_status from Users where manager_status=0";
        Connection con;
        ResultSet rs;
        PreparedStatement ps;
        ConnectData cd = new ConnectData();
        con = cd.connect();
        ps = con.prepareStatement(sql1);
        rs = ps.executeQuery();
        while (rs.next()) {
            String id=rs.getString(1);
            String username=rs.getString(2);
            String role=rs.getString(3);
            Boolean debt_status=rs.getBoolean(4);
            if (debt_status==true) model.addRow(new Vector<>(Arrays.asList(id,username,role,"Ƿ��")));
            else model.addRow(new Vector<>(Arrays.asList(id,username,role,"��Ƿ��")));
        }
        con.close();
    }
    public void selectmyUser(DefaultTableModel model,String name) throws Exception {
        String sql1 = "SELECT user_id,username,role,debt_status from Users where username=?";
        Connection con;
        ResultSet rs;
        PreparedStatement ps = null;
        ConnectData cd = new ConnectData();
        con = cd.connect();
        ps = con.prepareStatement(sql1);
        ps.setString(1,name);
        rs = ps.executeQuery();
        while (rs.next()) {
            String id=rs.getString(1);
            String username=rs.getString(2);
            String role=rs.getString(3);
            Boolean debt_status=rs.getBoolean(4);
            if (debt_status==true) model.addRow(new Vector<>(Arrays.asList(id,username,role,"Ƿ��")));
            else model.addRow(new Vector<>(Arrays.asList(id,username,role,"��Ƿ��")));
        }
        con.close();
    }
}