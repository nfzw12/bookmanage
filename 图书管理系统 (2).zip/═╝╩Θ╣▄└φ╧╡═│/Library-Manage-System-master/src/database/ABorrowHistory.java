package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;

import javax.swing.table.DefaultTableModel;

public class ABorrowHistory {
	/*��ʾ���н����¼*/
	public void allHistory(DefaultTableModel model)throws Exception{
		String sql = "select * from Record";
		Connection con;
		ResultSet rs;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps = con.prepareStatement(sql);
		rs = ps.executeQuery();
		while(rs.next()) {
			int bookid=rs.getInt(3);
			String borrower=rs.getString(2);
			Date Time = rs.getDate(1);
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(Time);
			calendar.add(Calendar.MONTH, 1);
			Date time = calendar.getTime();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String return_time= sdf.format(time);
			Boolean status=rs.getBoolean(4);
			if(!status)
				model.addRow(new Vector<>(Arrays.asList(bookid,borrower,Time,return_time,"δ��")));
			else model.addRow(new Vector<>(Arrays.asList(bookid,borrower,Time,return_time,"�ѻ�")));
		}
		con.close();
	}
	/*�����鱾���������ʷ*/
	public void bookSelect(DefaultTableModel model,int bookid) throws Exception {
		String sql = "select * from Record where Borrow_book_id = ?";
		Connection con;
		ResultSet rs;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps = con.prepareStatement(sql);
		ps.setInt(1,bookid);
		rs = ps.executeQuery();
		while(rs.next()) {
			String borrower=rs.getString(2);
			Boolean status=rs.getBoolean(4);
			Date Time = rs.getDate(1);
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(Time);
			calendar.add(Calendar.MONTH, 1);
			Date time = calendar.getTime();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String return_time= sdf.format(time);
			if(!status)
				model.addRow(new Vector<>(Arrays.asList(bookid,borrower,Time,return_time,"δ��")));
			else model.addRow(new Vector<>(Arrays.asList(bookid,borrower,Time,return_time,"�ѻ�")));
		}
		con.close();
	}
	/*���ս���������ͼ��*/
	public void borrowerSelect(DefaultTableModel model,String borrower) throws Exception{
		String sql = "select * from Record where Borrow_name like ?";
		Connection con;
		ResultSet rs;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps = con.prepareStatement(sql);
		borrower = "%" + borrower + "%";
		ps.setString(1, borrower);
		rs = ps.executeQuery();
		while(rs.next()) {
			int bookid=rs.getInt(3);
			borrower=rs.getString(2);
			Date Time=rs.getDate(1);
			Boolean status=rs.getBoolean(4);
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(Time);
			calendar.add(Calendar.MONTH, 1);
			Date time = calendar.getTime();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String return_time= sdf.format(time);
			if(!status)
				model.addRow(new Vector<>(Arrays.asList(bookid,borrower,Time,return_time,"δ��")));
			else model.addRow(new Vector<>(Arrays.asList(bookid,borrower,Time,return_time,"�ѻ�")));
		}
		con.close();
	}
}