package database;

import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class FineTake {
    public void updatestatus() throws Exception {
        String sql = "update x\n" +
                "set debt_status =1\n" +
                "from users x\n" +
                "JOIN record y on x.username=y.Borrow_name\n" +
                "where DATEADD(MONTH,1,y.Borrow_time)<getDate() and y.status=0";
        Connection con;
        PreparedStatement ps;
        ConnectData cd = new ConnectData();
        con = cd.connect();
        ps = con.prepareStatement(sql);
        int ok = ps.executeUpdate();
        con.close();
    }
}