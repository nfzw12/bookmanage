package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ManageUser {
	
	/*�����û�*/
	public static void addUser(String username, String password, String name) throws Exception{
		ResultSet rs ;
		Connection con;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		String sql = "insert into users values(?,?,?,0,0)";
		ps = con.prepareStatement(sql);
		ps.setString(1, username);
		ps.setString(2, password);
		ps.setString(3,name);
		int ok = ps.executeUpdate();
		con.close();
	}
	/*ɾ���û�*/
	public void deleteUser(String username) throws Exception{
		String sql = "delete from users where username = ?";
		Connection con;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps = con.prepareStatement(sql);
		ps.setString(1, username);
		int ok = ps.executeUpdate();
		con.close();
	}
	/*�޸�����*/
	public void changePass(String username) throws Exception{
		String sql = "update users set password = '666666' where username = ?";
		Connection con;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps = con.prepareStatement(sql);
		ps.setString(1, username);
		int ok = ps.executeUpdate();
		con.close();
	}
	/*�޸�����*/
	public void changeName(String username,String role) throws Exception{
		String sql = "update users set role = ? where username = ?";
		Connection con;
		PreparedStatement ps;
		ConnectData cd = new ConnectData();
		con = cd.connect();
		ps = con.prepareStatement(sql);
		ps.setString(1, role);
		ps.setString(2, username);
		int ok = ps.executeUpdate();
		con.close();
	}

}
