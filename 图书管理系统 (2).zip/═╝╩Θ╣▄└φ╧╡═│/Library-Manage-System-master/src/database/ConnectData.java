package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectData {
	public static Connection connect() {
		String url = "jdbc:sqlserver://localhost:1433;databaseName=bookmanage;encrypt=true;trustServerCertificate=true";
		//String url = "jdbc:mysql:// localhost:3306/us?serverTimezone=GMT%2B8";
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		}catch(Exception e) {}
		Connection con = null ;
		try {
			con = DriverManager.getConnection(url, "U1", "1111");
		}catch(SQLException e) {
		}
		return con;
	}
}
