package menu;

import database.ChangeInfoData;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;


public class ChangePassword {

    private String password1;
    private String password2;
    private String password3;
    private String borrower;
    private int flag = 0;
    public void setName(String borrower) {
        this.borrower = borrower;
    }
    public ChangePassword() {
        JFrame f = new JFrame();
        f.setSize(500, 600);
        f.setLocationRelativeTo(null);
        f.setLayout(null);
        f.setTitle("�޸�����");
        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 500, 600);
        panel.setLayout(null);

        //�ı䴰��ͼ��
        Toolkit tool = Toolkit.getDefaultToolkit();
        Image img = tool.getImage("picture\\symbol.jpg");
        f.setIconImage(img);

        /*���ô��ڱ���ͼ��*//*
        Icon i = new ImageIcon("picture\\admin_background.jpg");
        JLabel label = new JLabel(i);
        label.setBounds(0, 0, 500, 500);*/

        /*���5�������ǩ*/
        JLabel prepassword = new JLabel("������:");
        Font font2 = new Font("����", Font.BOLD, 25);
        prepassword.setFont(font2);
        prepassword.setBounds(50, 30, 200, 60);
        panel.add(prepassword);

        /*���5�������ı���*/
        JPasswordField textprepass = new JPasswordField();
        Dimension d = new Dimension(350, 45);
        textprepass.setFont(font2);
        textprepass.setSize(d);
        textprepass.setBounds(50, 80, 350, 45);
        panel.add(textprepass);

        /*�����ǩ*/
        JLabel password = new JLabel("���룺");
        password.setFont(font2);
        password.setBounds(50, 140, 600, 30);
        panel.add(password);

        /*�����ı���*/
        JPasswordField textpass = new JPasswordField();
        textpass.setFont(font2);
        textpass.setSize(d);
        textpass.setBounds(50, 190, 350, 45);
        panel.add(textpass);

        /*ȷ�������ǩ*/
        JLabel repassword = new JLabel("ȷ�����룺");
        repassword.setFont(font2);
        repassword.setBounds(50, 250, 600, 30);
        panel.add(repassword);

        /*ȷ�������ı���*/
        JPasswordField textrepass = new JPasswordField();
        textrepass.setFont(font2);
        textrepass.setSize(d);
        textrepass.setBounds(50, 300, 350, 45);
        panel.add(textrepass);

        /*ȷ���޸İ�ť*/
        JButton button = new JButton("ȷ���޸�");
        Font font = new Font("����", Font.BOLD, 16);
        button.setFont(font);
        button.setForeground(Color.black);
        button.setBackground(Color.white);
        button.setBounds(50, 400, 350, 50);
        panel.add(button);
        button.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                password1 = textprepass.getText().trim();
                password2 = textpass.getText().trim();
                password3 = textrepass.getText().trim();

                String regex = "\\p{Alnum}";
                ChangeInfoData ci = new ChangeInfoData();
                try {
                    flag = ci.checkPass(borrower, password1);
                } catch (Exception e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }

                if (flag == 1) {
                    if ((password2.length() < 6 || password2.length() > 12) || password2.matches(regex)) {
                        JOptionPane.showMessageDialog(null, "�������벻����Ҫ��", "����", JOptionPane.WARNING_MESSAGE);
                    } else {
                        if (!(password2.equals(password3))) {
                            JOptionPane.showMessageDialog(null, "��������������벻��ͬ", "����", JOptionPane.ERROR_MESSAGE);
                        } else {

                            try {
                                ci.savePass(password2, borrower);
                            } catch (Exception e1) {
                                // TODO Auto-generated catch block
                                e1.printStackTrace();
                            }
                            JOptionPane.showMessageDialog(null, "��Ϣ���ĳɹ�", "��ϲ", JOptionPane.PLAIN_MESSAGE);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "�Բ������ľ���������", "����������", JOptionPane.PLAIN_MESSAGE);
                }
            }
        });
        f.add(panel);
        panel.setOpaque(false);

        textprepass.setOpaque(false);
        textpass.setOpaque(false);
        textrepass.setOpaque(false);
        f.setVisible(true);
    }
}
