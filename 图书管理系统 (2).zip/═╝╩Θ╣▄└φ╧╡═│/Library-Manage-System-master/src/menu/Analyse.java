package menu;

import database.AnalyseData;
import database.BookData;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

public class Analyse extends JFrame {

    private DefaultTableModel model;
    JLayeredPane laypane = new JLayeredPane();
    public void setModel(DefaultTableModel model1) {
        this.model = model1;
    }
    public Analyse(){
        Font font1 = new Font("����",Font.BOLD,13);
        Font font2 = new Font("����",Font.BOLD,20);
        Toolkit tool = Toolkit.getDefaultToolkit();
        Image img = tool.getImage("picture\\symbol.jpg");
        this.setIconImage(img);

        /*���ô��ڱ���ͼ��*/
        Icon i = new ImageIcon("picture\\background.jpg");
        JLabel label = new JLabel(i);
        label.setBounds(0, 0, 1000, 800);


        /*���3�еı�ǩ*/
        Font font = new Font("����",Font.BOLD,40);
        JLabel lab3 = new JLabel("ͳ�ƽ����");
        lab3.setFont(font);
        lab3.setBounds(380, 50, 500, 100);

        /*ˢ�°�ť*/
        JButton button_ = new JButton("ˢ��");
        button_.setBackground(Color.white);
        button_.setBounds(800, 100, 120, 30);
        button_.setFont(font2);

        model = new DefaultTableModel();
        model.addColumn("�û�����",new Vector<String>());
        model.addColumn("�����鱾����",new Vector<String>());
        model.addColumn("Ƿ����Ա����", new Vector<Integer>());
        JTable table = new JTable(model);
        laypane.setOpaque(false);
        JScrollPane jp = new JScrollPane(table);
        jp.setBounds(100, 150, 750, 100);


        JTableHeader head = table.getTableHeader();//���������ͷ����
        head.setPreferredSize(new Dimension(head.getWidth(),35));//���ñ�ͷ����С
        head.setFont(new Font("����",Font.BOLD,15));//���ñ�������
        table.setRowHeight(30);//���ñ����п�
        table.setFont(new Font("����",Font.ROMAN_BASELINE,13));//���ñ������������С

        /*ʹ��Ԫ���е����ݾ���*/
        DefaultTableCellRenderer renderer=new DefaultTableCellRenderer();
        renderer.setHorizontalAlignment(DefaultTableCellRenderer.CENTER);
        table.setDefaultRenderer(Object.class, renderer);

        AnalyseData a1 = new AnalyseData();
        try {
            a1.selectAll(model);
        } catch (Exception e2) {
            e2.printStackTrace();
        }


        button_.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                model.setRowCount(0);
                try {
                    a1.selectAll(model);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });


        laypane.add(label, new Integer(0),0);
        laypane.add(lab3,new Integer(150),1);
        laypane.add(jp,new Integer(200),2);
        laypane.add(button_,new Integer(210),3);
    }

}