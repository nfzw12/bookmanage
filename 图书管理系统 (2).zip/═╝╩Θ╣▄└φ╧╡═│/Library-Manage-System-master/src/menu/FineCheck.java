package menu;

import database.FineTake;

public class FineCheck implements Runnable{
    @Override
    public void run() {
        FineTake fk=new FineTake();
        try {
            fk.updatestatus();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}