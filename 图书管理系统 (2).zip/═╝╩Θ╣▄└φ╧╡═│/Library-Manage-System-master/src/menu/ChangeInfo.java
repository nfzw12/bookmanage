package menu;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import database.AnalyseData;
import database.ChangeInfoData;

public class ChangeInfo extends JFrame{
	JLayeredPane laypane = new JLayeredPane();
	private DefaultTableModel model;
	private String password1;
	private String password2;
	private String password3;
	private String borrower;
	private int flag = 0;
	public void setName(String borrower) {

	}
	
	public ChangeInfo(String borrower) {
		this.borrower = borrower;
		Font font1 = new Font("����",Font.BOLD,13);
		Font font2 = new Font("����",Font.BOLD,20);
		Toolkit tool = Toolkit.getDefaultToolkit();
		Image img = tool.getImage("picture\\symbol.jpg");
		this.setIconImage(img);

		/*���ô��ڱ���ͼ��*/
		Icon i = new ImageIcon("picture\\background.jpg");
		JLabel label = new JLabel(i);
		label.setBounds(0, 0, 1000, 800);


		/*���3�еı�ǩ*/
		Font font = new Font("����",Font.BOLD,40);
		JLabel lab3 = new JLabel("������Ϣ��");
		lab3.setFont(font);
		lab3.setBounds(380, 50, 500, 100);

		/*ˢ�°�ť*/
		JButton button_ = new JButton("�޸�����");
		button_.setBackground(Color.white);
		button_.setBounds(400, 600, 200, 30);
		button_.setFont(font2);

		model = new DefaultTableModel();
		model.addColumn("�û����",new Vector<String>());
		model.addColumn("�û���",new Vector<String>());
		model.addColumn("����", new Vector<String>());
		model.addColumn("Ƿ��״̬", new Vector<String>());
		JTable table = new JTable(model);
		laypane.setOpaque(false);
		JScrollPane jp = new JScrollPane(table);
		jp.setBounds(100, 150, 750, 500);


		JTableHeader head = table.getTableHeader();//���������ͷ����
		head.setPreferredSize(new Dimension(head.getWidth(),35));//���ñ�ͷ����С
		head.setFont(new Font("����",Font.BOLD,15));//���ñ�������
		table.setRowHeight(30);//���ñ����п�
		table.setFont(new Font("����",Font.ROMAN_BASELINE,13));//���ñ������������С

		/*ʹ��Ԫ���е����ݾ���*/
		DefaultTableCellRenderer renderer=new DefaultTableCellRenderer();
		renderer.setHorizontalAlignment(DefaultTableCellRenderer.CENTER);
		table.setDefaultRenderer(Object.class, renderer);
		System.out.println(borrower);
		AnalyseData a1 = new AnalyseData();
		try {
			a1.selectmyUser(model,borrower);
		} catch (Exception e2) {
			e2.printStackTrace();
		}


		button_.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				try {
					ChangePassword cg=new ChangePassword();
					cg.setName(borrower);
				} catch (Exception ex) {
					throw new RuntimeException(ex);
				}
			}
		});


		laypane.add(label, new Integer(0),0);
		laypane.add(lab3,new Integer(150),1);
		laypane.add(jp,new Integer(200),2);
		laypane.add(button_,new Integer(210),3);
	}
		/*
		 * �޸���Ϣ
		 */
		

	}

