package menu;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Objects;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import database.BookData;
import database.ManageBook;

public class FixBook {

	public FixBook(DefaultTableModel model,int bookid,int stockquantity,String location,boolean status) {
		JFrame f = new JFrame();
		f.setSize(500, 550);
		f.setLocationRelativeTo(null);
		f.setLayout(null);
		f.setTitle("�޸�ͼ��");
		
		//�ı䴰��ͼ��
		Toolkit tool = Toolkit.getDefaultToolkit();
		Image img = tool.getImage("picture\\symbol.jpg");
		f.setIconImage(img);
		
		/*���ô��ڱ���ͼ��*/
/*		Icon i = new ImageIcon("picture\\admin_background.jpg");
		JLabel label = new JLabel(i);
		label.setBounds(0, 0, 500, 500);*/
		
		
		
		JPanel panel1 = new JPanel();
		JPanel panel2 = new JPanel();
		JPanel panel3 = new JPanel();
		JPanel panel4 = new JPanel();
		JPanel panel5 = new JPanel();
		JPanel panel6 = new JPanel();
		JPanel panel7 = new JPanel();

		Font font = new Font("����",Font.BOLD,30);
		Font font1 = new Font("����",Font.PLAIN,20);
		Dimension dimension = new Dimension(300,40);
		Dimension dimension1 = new Dimension(200,40);
		
		/*�������ǩ*/
		JLabel labStockQuantity = new JLabel("�������");
		labStockQuantity.setFont(font);
		panel1.add(labStockQuantity);
		panel1.setBounds(50, 30, 200, 60);
		
		/*����������ı���*/
		JTextField textStockQuantity = new JTextField(""+stockquantity);
		panel2.setLayout(null);
		textStockQuantity.setSize(dimension);
		textStockQuantity.setFont(font1);
		panel2.add(textStockQuantity);
		panel2.setBounds(100, 90, 500, 50);
		
		/*���ڵر�ǩ*/
		JLabel labLocation = new JLabel("���ڵأ�");
		labLocation.setFont(font);
		panel3.add(labLocation);
		panel3.setBounds(50, 160, 200, 60);
		
		/*���ڵ������ı���*/
		JTextField textLocation = new JTextField(location);
		panel4.setLayout(null);
		textLocation.setSize(dimension);
		textLocation.setFont(font1);
		panel4.add(textLocation);
		panel4.setBounds(100, 220, 500, 50);

		/*״̬��ǩ*/
		JLabel labStatus = new JLabel("״̬��");
		labStatus.setFont(font);
		panel5.add(labStatus);
		panel5.setBounds(50, 290, 200, 60);

		/*״̬�����ı���*/
		JTextField textStatus;
		if(status==false)textStatus=new JTextField("0");
		else textStatus=new JTextField("1");
		panel6.setLayout(null);
		textStatus.setSize(dimension);
		textStatus.setFont(font1);
		panel6.add(textStatus);
		panel6.setBounds(100, 350, 500, 50);
		
		
		/*���Ӱ�ť*/
		JButton button = new JButton("ȷ���޸�");
		button.setPreferredSize(dimension1);
		button.setBackground(Color.PINK);
		button.setFont(new Font("����",Font.BOLD,25));
		panel7.add(button);
		panel7.setBounds(150, 420, 200, 100);
		
		button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int StockQuantity=Integer.parseInt(textStockQuantity.getText().trim());
				String Location=textLocation.getText().trim();
				Boolean Status;
				if(Objects.equals(textStatus.getText(), "0"))Status=false;
				else Status=true;
				ManageBook mb = new ManageBook();
				try {
					mb.changeBook(bookid,StockQuantity,Location,Status);
					JOptionPane.showMessageDialog(null, "�޸ĳɹ�", "�޸�", JOptionPane.PLAIN_MESSAGE);
					BookData bd = new BookData();
					try {
						model.setRowCount(0);
						bd.selectAll(model);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				} catch (Exception e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
			}
		});
		
		
		f.add(panel1);
		f.add(panel2);
		f.add(panel3);
		f.add(panel4);
		f.add(panel5);
		f.add(panel6);
		f.add(panel7);
//		f.add(label);
		
/*		textbook.setOpaque(false);
		textauthor.setOpaque(false);
		panel1.setOpaque(false);
		panel2.setOpaque(false);
		panel3.setOpaque(false);
		panel4.setOpaque(false);
		panel5.setOpaque(false);*/
		
		f.setVisible(true);
	}
}
