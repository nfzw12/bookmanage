package menu;

import database.BookData;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class User extends JFrame{
	
		JTabbedPane tabpane;
	public User(String name){
			
		setTitle("ͼ�����ϵͳ");
		setSize(1000, 800);
		setLocationRelativeTo(null);
		Toolkit t =Toolkit.getDefaultToolkit();
		Image img = t.getImage("picture\\symbol.jpg");
		this.setIconImage(img);
		
		Icon i = new ImageIcon("picture\\signmenu.jpg");
		JLabel jLabel = new JLabel(i);
		jLabel.setBounds(0, 0, 1000, 800);

		Container c = getContentPane();
		tabpane = new JTabbedPane(JTabbedPane.TOP,JTabbedPane.SCROLL_TAB_LAYOUT);
		c.add(tabpane, BorderLayout.CENTER);

		tabpane.setFont(new Font("����",Font.BOLD,18));
		tabpane.setBackground(Color.white);
		
		/*������*/
		MainMenu mm = new MainMenu(name);
		tabpane.addTab("������",mm.panel);
		
		/*����ͼ�����*/
		SearchBook sb = new SearchBook();
		sb.setName(name);
		tabpane.addTab("ͼ�����", sb.laypane);
		
		/*������ʷ����*/
		BorrowHistory bh = new BorrowHistory();
		bh.setName(name);
		bh.setPanel();
		sb.setModel(bh.model);
		tabpane.addTab("������ʷ", bh.laypane);

		/*�޸���Ϣ����*/
		ChangeInfo ci = new ChangeInfo(name);

		tabpane.addTab("������Ϣ", ci.laypane);


		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
		
		


		
}
	
	
		
		
	
	
