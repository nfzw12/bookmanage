package menu;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Objects;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import database.BookData;
import database.ManageBook;

public class AddBook {
	
	public AddBook(DefaultTableModel model) {
		JFrame f = new JFrame();
		f.setSize(500, 650);
		f.setLocationRelativeTo(null);
		f.setLayout(null);
		f.setTitle("����ͼ��");
		
		//�ı䴰��ͼ��
		Toolkit tool = Toolkit.getDefaultToolkit();
		Image img = tool.getImage("picture\\symbol.jpg");
		f.setIconImage(img);
		
		/*���ô��ڱ���ͼ��*/
/*		Icon i = new ImageIcon("picture\\admin_background.jpg");
		JLabel label = new JLabel(i);
		label.setBounds(0, 0, 500, 700);*/
		
		
		
		JPanel panel1 = new JPanel();
		JPanel panel2 = new JPanel();
		JPanel panel3 = new JPanel();
		JPanel panel4 = new JPanel();
		JPanel panel5 = new JPanel();
		JPanel panel6 = new JPanel();
		JPanel panel7 = new JPanel();
		JPanel panel8 = new JPanel();
		JPanel panel9 = new JPanel();
		JPanel panel10 = new JPanel();
		JPanel panel11 = new JPanel();
		JPanel panel12 = new JPanel();
		JPanel panel13 = new JPanel();
		JPanel panel14 = new JPanel();
		JPanel panel15 = new JPanel();
		
		Font font = new Font("����",Font.BOLD,30);
		Font font1 = new Font("����",Font.PLAIN,20);
		Dimension dimension = new Dimension(300,40);
		Dimension dimension1 = new Dimension(200,40);
		
		/*������ǩ*/
		JLabel labbook = new JLabel("������");
		labbook.setFont(font);
		panel1.add(labbook);
		panel1.setBounds(25, 50, 100, 60);
		
		/*���������ı���*/
		JTextField textbook = new JTextField(12);
		panel2.setLayout(null);
		textbook.setSize(dimension);
		textbook.setFont(font1);
		panel2.add(textbook);
		panel2.setBounds(125, 50, 350, 60);
		
		/*���߱�ǩ*/
		JLabel labauthor = new JLabel("���ߣ�");
		labauthor.setFont(font);
		panel3.add(labauthor);
		panel3.setBounds(25, 110, 100, 60);
		
		/*���������ı���*/
		JTextField textauthor = new JTextField(12);
		panel4.setLayout(null);
		textauthor.setSize(dimension);
		textauthor.setFont(font1);
		panel4.add(textauthor);
		panel4.setBounds(125, 110, 350, 60);

		/*��ű�ǩ*/
		JLabel labID = new JLabel("��ţ�");
		labID.setFont(font);
		panel5.add(labID);
		panel5.setBounds(25, 170, 100, 60);

		/*��������ı���*/
		JTextField textID = new JTextField(12);
		panel6.setLayout(null);
		textID.setSize(dimension);
		textID.setFont(font1);
		panel6.add(textID);
		panel6.setBounds(125, 170, 350, 60);

		/*����ǩ*/
		JLabel labStockQuantity = new JLabel("��棺");
		labStockQuantity.setFont(font);
		panel7.add(labStockQuantity);
		panel7.setBounds(25, 230, 100, 60);

		/*��������ı���*/
		JTextField textStockQuantity = new JTextField(12);
		panel8.setLayout(null);
		textStockQuantity.setSize(dimension);
		textStockQuantity.setFont(font1);
		panel8.add(textStockQuantity);
		panel8.setBounds(125, 230, 350, 60);

		/*λ�ñ�ǩ*/
		JLabel labLocation = new JLabel("λ�ã�");
		labLocation.setFont(font);
		panel9.add(labLocation);
		panel9.setBounds(25, 290, 100, 60);

		/*λ�������ı���*/
		JTextField textLocation = new JTextField(12);
		panel10.setLayout(null);
		textLocation.setSize(dimension);
		textLocation.setFont(font1);
		panel10.add(textLocation);
		panel10.setBounds(125, 290, 350, 60);

		/*���ͱ�ǩ*/
		JLabel labType = new JLabel("���ͣ�");
		labType.setFont(font);
		panel11.add(labType);
		panel11.setBounds(25, 350, 100, 60);

		/*���������ı���*/
		JTextField textType = new JTextField(12);
		panel12.setLayout(null);
		textType.setSize(dimension);
		textType.setFont(font1);
		panel12.add(textType);
		panel12.setBounds(125, 350, 350, 60);

		/*״̬��ǩ*/
		JLabel labStatus = new JLabel("״̬��");
		labStatus.setFont(font);
		panel13.add(labStatus);
		panel13.setBounds(25, 410, 100, 60);

		/*״̬�����ı���*/
		JTextField textStatus = new JTextField(12);
		panel14.setLayout(null);
		textStatus.setSize(dimension);
		textStatus.setFont(font1);
		panel14.add(textStatus);
		panel14.setBounds(125, 410, 350, 60);

		/*���Ӱ�ť*/
		JButton button = new JButton("ȷ������");
		button.setPreferredSize(dimension1);
		button.setBackground(Color.PINK);
		button.setFont(new Font("����",Font.BOLD,25));
		panel15.add(button);
		panel15.setBounds(150, 500, 200, 100);
		
		button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String bookTitle = textbook.getText().trim();
				String author = textauthor.getText().trim();
				int ID=Integer.parseInt(textID.getText().trim());
				int StockQuantity=Integer.parseInt(textStockQuantity.getText().trim());
				String Location=textLocation.getText().trim();
				String BookType=textType.getText().trim();
				Boolean Status;
				if(Objects.equals(textStatus.getText(), "0"))Status=false;
				else Status=true;

				ManageBook mb = new ManageBook();
				try {
					mb.addBook(bookTitle, author,ID,StockQuantity,Location,BookType,Status);
					JOptionPane.showMessageDialog(null, "���ӳɹ�", "����", JOptionPane.PLAIN_MESSAGE);
					
					BookData bd = new BookData();
					try {
						model.setRowCount(0);
						bd.selectAll(model);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		
		f.add(panel1);
		f.add(panel2);
		f.add(panel3);
		f.add(panel4);
		f.add(panel5);
		f.add(panel6);
		f.add(panel7);
		f.add(panel8);
		f.add(panel9);
		f.add(panel10);
		f.add(panel11);
		f.add(panel12);
		f.add(panel13);
		f.add(panel14);
		f.add(panel15);
		/*f.add(label);*/
		
/*		textbook.setOpaque(false);
		textauthor.setOpaque(false);
		textID.setOpaque(false);
		panel1.setOpaque(false);
		panel2.setOpaque(false);
		panel3.setOpaque(false);
		panel4.setOpaque(false);
		panel5.setOpaque(false);
		panel6.setOpaque(false);
		panel7.setOpaque(false);*/
		f.setVisible(true);
	}
}
